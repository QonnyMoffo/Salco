class Paths(object):
	apps = {
		'Revisión de contenido': '/revision_contenido',
		'Revisión de bulto': '/revision_bulto',	
	}
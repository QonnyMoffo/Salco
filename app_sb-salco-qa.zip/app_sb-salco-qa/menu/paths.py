class Paths(object):
	apps = {
		'Revision de contenido': '/revision_contenido',
		'Revision de bulto': '/revision_bulto',	
	}

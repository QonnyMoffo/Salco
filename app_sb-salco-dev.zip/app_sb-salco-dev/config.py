import os
basedir = os.path.abspath(os.path.dirname(__file__))

class Vars(object):
	IP = os.environ.get('RCM_VE_IP', None) #0.0.0.0
	PORT = os.environ.get('RCM_VE_PORT', None) #8080
	
class Timer(object):
	SEG = os.environ.get('RCM_VE_SEG', None) #9000
	
class Server(object):
	LINK = os.environ.get('RCM_VE_LINK', None) #apiqa.sb.cl/desa/recepion-ciega/movil
	API_KEY = os.environ.get('RCM_VE_API_KEY', None) #&api_key=PkHLgc0pSMUpuBq3HZZ7d0dRFoGKxmPl1h6l75bQ
	
class Aplication(object):
	NAME = os.environ.get('RCM_VE_NAME', None) #RCM
	
if Vars.IP is None or Vars.PORT is None or Timer.SEG is None or Server.LINK is None or Server.API_KEY is None or Aplication.NAME is None:
	exit()
	
	
class Config(object):
    DEBUG = False
    TESTING = False
    CSRF_ENABLED = True
    SECRET_KEY = '123dasdasdg3sd21as-11slk'
    
class ProductionConfig(Config):
    DEBUG = False
	
class StagingConfig(Config):
    DEVELOPMENT = True
    DEBUG = True
	
class DevelopmentConfig(Config):
    DEVELOPMENT = True
    DEBUG = True
	
class TestingConfig(Config):
    TESTING = True
